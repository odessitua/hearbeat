HearBeat — візуальні артефакти (8 шт)
Стиль: стриманий продуктовий, Manrope, sea-wave акцент. PNG @3x, біле тло.

У ДОСЛІДНИЦЬКУ БАЗУ (hearbeat_ux-research-dossier-v2.md):
  hearbeat_persona_marta_payer.png        — персона Марти (платниця)
  hearbeat_persona_nina_gatekeeper.png    — персона Ніни (gatekeeper адопції)
  hearbeat_empathy_map_marta.png          — empathy map
  hearbeat_jtbd_forces.png                — JTBD, 4 сили
  hearbeat_competitive_matrix.png         — конкурентна матриця ✓/✕
  hearbeat_metrics_and_problem_statement.png — метрики + problem statement

У ПІТЧ (3 найсильніші):
  hearbeat_quantified_pain_points.png     — Слайд 1 (біль, суддя В)
  hearbeat_cjm_emotion_curve_v2.png       — Слайд 2 (сліпа зона, product-thinking)
  hearbeat_positioning_map.png            — Слайд 4 (порожній квадрант, суддя А+Б)

Вставляй на плейсхолдери [ВІЗУАЛ: назва] у відповідних .md файлах.
